package org.modeldriven.alf.execution.fuml;

public interface OpaqueBehaviorExecution {

}
